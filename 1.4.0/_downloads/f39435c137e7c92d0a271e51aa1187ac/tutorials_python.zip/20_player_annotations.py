"""
.. _tut-player-annotations:

Player with annotations
=======================

.. include:: ./../../links.inc
"""
